import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MyStepdefAmazon  {
    private Baseclass base;

    public MyStepdefAmazon(Baseclass baseclass) {
        this.base = base;
    }

    @Given("i Open amazon website")
    public void iOpenAmazonWebsite() {
        System.out.println(base.driver.getTitle());
    }


    @Then("I will be able to see homepage")
    public void iWillBeAbleToSeeHomepage() {

        System.out.println("Homepage displayed succesfully");
    }

    @And("I enter  as {string} in search box")
    public void iEnterItemInSearchBox(String item) {
        base.driver.findElement(By.id("twotabsearchtextbox")).sendKeys(item+ Keys.ENTER);
    }

    @When("I click on search")
    public void iClickOnSearch() {

    }



    @Then("I will be able to see list of item as {string}")
    public void iWillBeAbleToSeeListOfItemAsItem(String item) {
        System.out.println("\n Dispalyed list="+item);
        WebDriverWait wait = new WebDriverWait(base.driver,10) ;
        WebElement element =base.driver.findElement(By.xpath("//span[contains(text(),'"+item+"')]"));
        wait.until(ExpectedConditions.visibilityOf(element));
        String actualresult =element.getText();
        actualresult =actualresult.replace("\"","");
        System.out.println(actualresult);
        Assert.assertEquals(item,actualresult);
    }

    @Then("User will be searching again")
    public void userWillBeSearchingAgain() {
        System.out.println("Print fiunction");
    }
}
