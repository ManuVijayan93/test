import org.openqa.selenium.WebDriver;

public class Baseclass {

    public static WebDriver driver;

}
