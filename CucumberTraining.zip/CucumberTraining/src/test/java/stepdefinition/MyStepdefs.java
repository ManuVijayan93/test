package stepdefinition;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;
import org.junit.Assert;

import java.util.List;

public class MyStepdefs {
    @Given("I open the login page")
    public void i_open_the_login_page() {

        System.out.println("open login page");

    }

    @Given("I enter the username as {string}")
    public void i_enter_the_username(String username) {
        System.out.println("username entered"+username);
    }

    @Given("I enter the password as {string}")
    public void i_enter_the_password(String password) {
        System.out.println("password entered"+password);
    }

    @Given("I click on submit")
    public void i_click_on_submit() {
        System.out.println("clicked on submit");
    }

    @Then("I should see home Page with message as {string}")
    public void i_should_see_home_Page (String message)  {

        System.out.println(message);

    }

}
