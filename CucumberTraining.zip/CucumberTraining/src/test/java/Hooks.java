import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Hooks  {

    private Baseclass base;
    @Before
    public void openBrowser()
    {
        String path= System.getProperty("user.dir");
        
        path= path+ "\\src\\test\\driver\\chromedriver.exe";
        System.out.println(path);
        System.setProperty("webdriver.chrome.driver",path);
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("useAutomationExtension",false);
        base.driver=new ChromeDriver(options);
        base.driver.manage().window().maximize();
        base.driver.navigate().to("https://www.amazon.in");

    }


    @After
    public void teardown(Scenario scenario)
    {
        System.out.println(scenario.getStatus());
    }


}
